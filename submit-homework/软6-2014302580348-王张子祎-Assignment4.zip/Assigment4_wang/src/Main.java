

public class Main {
	
	public static void main(String[] args){
		UiThread uithread = new UiThread();
		Thread thread = new Thread(uithread);  
		thread.start();  
	}
	

}
