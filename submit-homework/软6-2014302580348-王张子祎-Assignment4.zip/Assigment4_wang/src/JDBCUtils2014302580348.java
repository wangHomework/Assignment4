
import java.sql.*;
import com.mysql.*;



public class JDBCUtils2014302580348 {

	
	//private static String url="jdbc:mysql://127.0.0.1:3306/assignment3?useUnicode=true&characterEncoding=utf8";
	private static String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private static String username = "root";
	private static String password = "";
	
	private static String driverName = "com.mysql.jdbc.Driver";

	
	static{
		try{
			Class.forName(driverName);
		}catch (ClassNotFoundException e) {
			throw new ExceptionInInitializerError(e);
		}
	}
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, username, password);
	}

	public static void free(ResultSet rs, Statement st, Connection conn) {
		try {
			if (rs != null)
				rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		}
	}
	public static void free(Connection conn) {
		try {
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}
