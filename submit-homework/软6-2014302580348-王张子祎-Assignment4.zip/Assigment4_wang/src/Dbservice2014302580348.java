

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Dbservice2014302580348 {
	Connection conn=null;
	public Dbservice2014302580348(Connection conn){
		this.conn=conn;
	}


	public void addTeacher(TeacherBean2014302580348 teacher)throws SQLException{
		PreparedStatement ps = null;
		String sql = "insert into teacher (url,name,blog,sex,levelc,education,phone,office,email,teach,showc) values ('"
		+ teacher.getUrl()+ "','" + teacher.getName()+ "','" + teacher.getBlog()+ "','" + teacher.getSex()+ "','"
		+ teacher.getLevel()+ "','" + teacher.getEducation()+ "','" + teacher.getPhone()+ "','" + teacher.getOffice()+ "','"
		+ teacher.getEmail()+ "','" + teacher.getTeach()+ "','" + teacher.getShow()+ "')";
		ps=(PreparedStatement) conn.prepareStatement(sql);
		
		ps.executeLargeUpdate(sql);
		
		ps.close();
	}
	
	/**
	 * 返回所有老师的信息
	 */
	public List<TeacherBean2014302580348> getTeacher(String keywords) throws SQLException{
		List<TeacherBean2014302580348> teacherList=new ArrayList<TeacherBean2014302580348>();
		ResultSet rs=null;
		PreparedStatement ps=null;
		String sql = "SELECT * FROM teacher WHERE concat(url,name,blog,sex,levelc,education,phone,office,email,teach,showc) LIKE '%"+keywords+ "%'";
    	ps=conn.prepareStatement(sql);//返回整个结果集
    	rs=ps.executeQuery();
    	while(rs.next()){//还要防止空空对比的情况
    		String url=rs.getString("url");
    		String name=rs.getString("name");
    		String blog=rs.getString("blog");
    		String sex=rs.getString("sex");
    		String levelc=rs.getString("levelc");
    		String education=rs.getString("education");
    		String phone=rs.getString("phone");
    		String office=rs.getString("office");
    		String email=rs.getString("email");
    		String teach=rs.getString("teach");
    		String showc=rs.getString("showc");
    		TeacherBean2014302580348 teacher = new TeacherBean2014302580348(url, name, blog, sex, levelc, education, phone, office, email, teach, showc);

    		teacherList.add(teacher);
    	}
		return teacherList;
	}
	

	
	
}
