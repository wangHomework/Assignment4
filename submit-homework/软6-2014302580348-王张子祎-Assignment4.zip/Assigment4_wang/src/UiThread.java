import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class UiThread implements Runnable {
	JFrame jframe;
	JTextField jtextField;
	JButton jbutton;
	JTextArea jtextArea;
	JScrollPane scroll=null;
	@Override
	public void run(){
		// TODO Auto-generated method stub
		jframe = new JFrame();
		jframe.getContentPane().setLayout(null);
		jframe.setBounds(100, 100, 490, 400);//左边距、上边距、宽度、高度
		
		jtextField = new JTextField();
		jtextField.setBounds(10, 10, 200, 20);
		jframe.getContentPane().add(jtextField);
		
		jtextArea = new JTextArea();
		jtextArea.setEditable(false);
		jtextArea.setLineWrap(true);
		jtextArea.setWrapStyleWord(true);
		jtextArea.setBounds(10, 40, 450, 310);
		jframe.getContentPane().add(jtextArea);
		
		jbutton = new JButton("search");
		jbutton.setBounds(220, 10, 100, 20);
		jframe.getContentPane().add(jbutton);
		
		jbutton.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				String keywords=jtextField.getText();
				
				try {
					Connection conn=null;
					Dbservice2014302580348 db=null;
					conn = JDBCUtils2014302580348.getConnection();
					db = new Dbservice2014302580348(conn);
					List<TeacherBean2014302580348> teacherList = new ArrayList<TeacherBean2014302580348>();
					teacherList = db.getTeacher(keywords);
					//词频(term frequency, TF)指的是该文章中某个词出现的次数除以该文章的总词数。
					List<Double> tfArray = new ArrayList<Double>();
					for(int i=0;i<teacherList.size();i++){
						TeacherBean2014302580348 currentTeacher = teacherList.get(i);
						String all = currentTeacher.getAllString();
						int times=0;
						String replaced = all.replaceAll(keywords, "");
						//(LENGTH('abcdabcdabcdabcdabcd') - LENGTH(REPLACE('abcdabcdabcdabcdabcd',"abc", ""))) / LENGTH("abc") 
						times = ( all.length() - replaced.length() ) / keywords.length();
						Double tf = times*1.0/all.length();
						tfArray.add( tf );
					}
					//冒泡排序
					
					for(int i=0;i<tfArray.size()-1;i++){
						Double currentCompared = tfArray.get(i);
						for(int j=i+1;j<tfArray.size()-1;j++){
							Double currentComparedTwo = tfArray.get(j);
							if(currentCompared<currentComparedTwo){
								Double temp = currentCompared;
								tfArray.set(i, tfArray.get(j));
								tfArray.set(j, temp);
								
								TeacherBean2014302580348 tempTeacher = new TeacherBean2014302580348();
								tempTeacher = teacherList.get(i);
								teacherList.set(i, teacherList.get(j));
								teacherList.set(j, tempTeacher);
								
							}
						}
					}
					String result="";
					for(int i=0;i<teacherList.size();i++){
						TeacherBean2014302580348 tempTeacher = teacherList.get(i);
						String url = "url:"+tempTeacher.getUrl();
						result = result + url + "\n";
						result = result + tempTeacher.getName() + "\n";
						result = result + tempTeacher.getBlog() + "\n";
						result = result + tempTeacher.getSex() + "\n";
						result = result + tempTeacher.getLevel() + "\n";
						result = result + tempTeacher.getEducation() + "\n";
						result = result + tempTeacher.getPhone() + "\n";
						result = result + tempTeacher.getOffice() + "\n";
						result = result + tempTeacher.getEmail() + "\n";
						result = result + tempTeacher.getTeach() + "\n";
						String show = "简介:"+tempTeacher.getShow();
						result = result + show + "\n";
						
						result = result + "-------------------------------------------" + "\n";
					}
					jtextArea.setText(result);
					if(scroll!=null){
						jframe.remove(scroll);
					}
					
					scroll = new JScrollPane(jtextArea); 
					scroll.setHorizontalScrollBarPolicy( 
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
					scroll.setVerticalScrollBarPolicy( 
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 
					scroll.setBounds(10, 40, 450, 310);
					
					jframe.getContentPane().add(scroll);
					
					jframe.setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		

		
		
		
		
		
		
		
		
		jframe.setVisible(true);
	}  

}  