
public class TeacherBean2014302580348 {
	private String url;
	private String name;
	private String blog;
	private String sex;
	private String level;
	private String education;
	private String phone;
	private String office;
	private String email;
	private String teach;
	private String show;
	public String getAllString(){
		String all="";
		all = all +url;
		all = all +name;
		all = all +blog;
		all = all +sex;
		all = all +level;
		all = all +education;
		all = all +phone;
		all = all +office;
		all = all +email;
		all = all +teach;
		all = all +show;
		return all;
	}
	public TeacherBean2014302580348(){}
	public TeacherBean2014302580348(String url,String name,String blog,String sex,String level,String education,String phone,String office,String email,String teach,String show){
		this.url=url;
		this.name=name;
		this.blog=blog;
		this.sex=sex;
		this.level=level;
		this.education=education;
		this.phone=phone;
		this.office=office;
		this.email=email;
		this.teach=teach;
		this.show=show;
		
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBlog() {
		return blog;
	}
	public void setBlog(String blog) {
		this.blog = blog;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTeach() {
		return teach;
	}
	public void setTeach(String teach) {
		this.teach = teach;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
}
